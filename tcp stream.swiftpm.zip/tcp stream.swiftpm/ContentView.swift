import Foundation
import Network
import SwiftUI

func hexString(from data: Data) -> String {
    return data.map { String(format: "%02x", $0) }.joined()
}

class TCPClient: NSObject, ObservableObject {
    private let host: String
    private let port: Int
    private var inputStream: InputStream?
    private var outputStream: OutputStream?
    private var receiveBuffer = Data()
    
    init(host: String, port: Int) {
        self.host = host
        self.port = port
    }
    
    func connect() {
        Stream.getStreamsToHost(withName: host, port: port, inputStream: &inputStream, outputStream: &outputStream)
        inputStream?.delegate = self
        outputStream?.delegate = self
        inputStream?.schedule(in: .current, forMode: .default)
        outputStream?.schedule(in: .current, forMode: .default)
        inputStream?.open()
        outputStream?.open()
    }
    
    func disconnect() {
        inputStream?.close()
        outputStream?.close()
        inputStream?.remove(from: .current, forMode: .default)
        outputStream?.remove(from: .current, forMode: .default)
        inputStream?.delegate = nil
        outputStream?.delegate = nil
        inputStream = nil
        outputStream = nil
    }
    
    private func receiveData() {
        let bufferSize = 1024
        var buffer = [UInt8](repeating: 0, count: bufferSize)
        while inputStream?.hasBytesAvailable == true {
            let bytesRead = inputStream!.read(&buffer, maxLength: bufferSize)
            if bytesRead > 0 {
                let data = Data(bytes: buffer, count: bytesRead)
                // Append the received data to the buffer
                receiveBuffer.append(data)
                
                // Check if the buffer contains a complete packet
                while let packetRange = receiveBuffer.range(of: Data([0x25, 0xEB])) {
                    let packet = receiveBuffer.prefix(upTo: packetRange.lowerBound)
                    receiveBuffer.removeSubrange(..<packetRange.upperBound)
                    
                    // Handle the received packet here
                    if !packet.isEmpty {
                        print("Received packet: \(hexString(from: packet))")
                    }
                }
            } else if bytesRead < 0 {
                if let error = inputStream?.streamError {
                    print("Error receiving data: \(error.localizedDescription)")
                }
                break
            }
        }
    }
}

extension TCPClient: StreamDelegate {
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
        switch eventCode {
        case .openCompleted:
            print("Connection ready")
            if aStream == inputStream {
                receiveData()
            }
        case .hasBytesAvailable:
            if aStream == inputStream {
                receiveData()
            }
        case .errorOccurred:
            if let error = aStream.streamError {
                print("Connection error: \(error.localizedDescription)")
            }
        case .endEncountered:
            print("Connection closed")
            disconnect()
        default:
            break
        }
    }
}

struct ContentView: View {
    @ObservedObject var tcp = TCPClient(host: "10.192.78.249", port: 2023)
    
    
    func onClick(){
        var myData = tcp.connect()
    }
    
    
    var body: some View {
        
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
            Button(action: onClick){
                Text("Receive Data")
            }
        }
        
    } // End of body
}
