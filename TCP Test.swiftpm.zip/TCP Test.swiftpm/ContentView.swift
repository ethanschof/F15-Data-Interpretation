import Foundation
import Network
import SwiftUI


func hexString(from data: Data) -> String {
    return data.map { String(format: "%02x", $0) }.joined()
}

class TCPClient: ObservableObject{
    private let host: NWEndpoint.Host
    private let port: NWEndpoint.Port
    private var connection: NWConnection?
    private var receiveBuffer = Data()
        
    init(host: String, port: Int) {
        self.host = NWEndpoint.Host(host)
        self.port = NWEndpoint.Port(rawValue: UInt16(port))!
        }
        
        func connect() {
            let parameters = NWParameters.tcp
            connection = NWConnection(host: host, port: port, using: parameters)
            connection?.stateUpdateHandler = { [weak self] newState in
                switch newState {
                case .ready:
                    print("Connection ready")
                    self?.receiveData()
                case .failed(let error):
                    print("Connection failed: \(error.localizedDescription)")
                default:
                    break
                }
            }
            connection?.start(queue: .global())
        }
        
        func disconnect() {
            connection?.cancel()
        }
        
    private func receiveData() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] (data, _, isComplete, error) in
            if let data = data, !data.isEmpty {
                // Append the received data to the buffer
                self?.receiveBuffer.append(data)
                
                // Check if the buffer contains a complete packet
                while let packetRange = self?.receiveBuffer.range(of: Data([0x25, 0xEB])) {
                    let packet = self?.receiveBuffer.prefix(upTo: packetRange.lowerBound)
                    self?.receiveBuffer.removeSubrange(..<packetRange.upperBound)
                    
                    // Handle the received packet here
                    if let packet = packet {
                        print("Received packet: \(hexString(from: packet))")
                    }
                }
            }
            if let error = error {
                print("Error receiving data: \(error.localizedDescription)")
            }
            if !isComplete {
                self?.receiveData()
            } else {
                print("Connection closed")
            }
        }
    }
}

struct ContentView: View {
    @ObservedObject var tcp = TCPClient(host: "10.192.78.249", port: 2023)
    
    
    func onClick(){
        var myData = tcp.connect()
    }
    
    
    var body: some View {
        
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
            Button(action: onClick){
                Text("Receive Data")
            }
        }
        
    } // End of body
}
